import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class RentedPropertyPageNew extends StatefulWidget {
  final String id;
  final String subid;

  const RentedPropertyPageNew({Key? key, required this.id, required this.subid})
      : super(key: key);

  @override
  State<RentedPropertyPageNew> createState() => _RentedPropertyPageNewState();
}

class _RentedPropertyPageNewState extends State<RentedPropertyPageNew> {
  bool _loading = false;
  String _responseMessage = "";

  Future<void> _performAllActions() async {
    setState(() {
      _loading = true;
      _responseMessage = "";
    });

    // --- build current IST date/time strings once, reuse everywhere ---
    String _2(int n) => n < 10 ? '0$n' : '$n';
    final nowUtc = DateTime.now().toUtc();
    final ist = nowUtc.add(const Duration(hours: 5, minutes: 30)); // Asia/Kolkata
    final bookingDate = '${ist.year}-${_2(ist.month)}-${_2(ist.day)}';       // YYYY-MM-DD
    final bookingTime = '${_2(ist.hour)}:${_2(ist.minute)}:${_2(ist.second)}'; // HH:MM:SS

    final url = Uri.parse(
      "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_realestate/book_flat_for_fieldworkar.php",
    );

    try {
      // 1. Copy (now with real date/time)
      final copyResponse = await http.post(url, body: {
        "action": "copy",
        "p_id": widget.id,
        "booking_date": bookingDate,
        "booking_time": bookingTime,
      });

      _responseMessage += copyResponse.statusCode == 200
          ? "✅ Copy Success: ${copyResponse.body}\n"
          : "❌ Copy Failed: ${copyResponse.statusCode}\n";

      // 2. Update
      final updateResponse = await http.post(url, body: {
        "action": "update",
        "subid": widget.subid,
      });

      _responseMessage += updateResponse.statusCode == 200
          ? "✅ Update Success: ${updateResponse.body}\n"
          : "❌ Update Failed: ${updateResponse.statusCode}\n";

      // 3. Delete
      final deleteResponse = await http.post(url, body: {
        "action": "delete",
        "p_id": widget.id,
      });

      _responseMessage += deleteResponse.statusCode == 200
          ? "✅ Delete Success: ${deleteResponse.body}"
          : "❌ Delete Failed: ${deleteResponse.statusCode}";
    } catch (e) {
      _responseMessage += "⚠ Exception: $e";
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Rented Property"),
        backgroundColor: Colors.black,
        surfaceTintColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text("Property ID: ${widget.id}",
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 24),

              // ✅ Single Button
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                onPressed: _loading ? null : _performAllActions,
                child: const Text(
                  "Book",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontFamily: "PoppinsBold"),
                ),
              ),

              const SizedBox(height: 24),

              if (_loading) const CircularProgressIndicator(),
              if (_responseMessage.isNotEmpty)
                Text(_responseMessage,
                    style: const TextStyle(fontSize: 14, height: 1.4)),
            ],
          ),
        ),
      ),
    );
  }
}
