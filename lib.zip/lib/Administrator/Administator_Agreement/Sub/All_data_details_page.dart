import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:http/http.dart' as http;
import 'package:open_filex/open_filex.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../Custom_Widget/Custom_backbutton.dart';
import '../../../model/Additional_agreement_tenants.dart';
import '../../imagepreviewscreen.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';

import '../PDFs/Commercial_PDF.dart';
import '../PDFs/PDF.dart';
import '../PDFs/furnished pdf.dart';
import 'Accepted_details.dart';

class AllDataDetailsPage extends StatefulWidget {
  final String agreementId;
  const AllDataDetailsPage({super.key, required this.agreementId});

  @override
  State<AllDataDetailsPage> createState() => _AgreementDetailPageState();
}

class _AgreementDetailPageState extends State<AllDataDetailsPage> {
  Map<String, dynamic>? agreement;
  bool isLoading = true;
  File? pdfFile;
  List<AdditionalTenant> additionalTenants = [];
  bool pdfGenerated = false;
  Widget? propertyCard;



  @override
  void initState() {
    super.initState();
    _loadAllData();
  }



  Future<void> fetchPropertyCard() async {
    final propertyId = agreement?["property_id"];
    if (propertyId == null || propertyId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Property ID not found")),
      );
      return;
    }

    try {
      final response = await http.post(
        Uri.parse("https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_realestate/display_api_base_on_flat_id.php"),
        body: {"P_id": propertyId},
      );

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);

        if (json['status'] == "success") {
          final data = json['data'];

          setState(() {
            propertyCard = _propertyCard(data);
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(json['message'] ?? "Property not found")),
          );
        }
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to fetch property details")),
      );
    }
  }

  Future<void> _loadAllData() async {
    setState(() {
      isLoading = true;
    });

    await Future.wait([
      _fetchAgreementDetail(),
      fetchAdditionalTenants(widget.agreementId),
    ]);

    setState(() {
      isLoading = false;
    });
  }

  Future<void> fetchAdditionalTenants(String agreementId) async {
    final url = Uri.parse(
      "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/agreement/show_api_addional_tenant_final.php?agreement_id=$agreementId",
    );

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final decoded = jsonDecode(response.body);

      if (decoded["success"] == true) {
        final List list = decoded["data"];

        setState(() {
          additionalTenants =
              list.map((e) => AdditionalTenant.fromJson(e)).toList();
        });
      }
    }
  }

  Future<void> _handleGeneratePdf() async {
    if (agreement == null) return;

    File file;

    final String type = (agreement!['agreement_type'] ?? '').toString().trim();

    setState(() => isLoading = true);

    try {

      if (type == "Furnished Agreement") {
        file = await generateFurnishedAgreementPdf(agreement!);
      }
      else if (type == "Commercial Agreement") {
        file = await generateCommercialAgreementPdf(agreement!);
      } else {
        file = await generateAgreementPdf(agreement!);
      }

      setState(() {
        pdfFile = file;
        pdfGenerated = true;
      });
    } catch (e) {
      debugPrint("PDF Generation Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to generate PDF: $e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _pickAndUploadPoliceVerification() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null && result.files.single.path != null) {
      File file = File(result.files.single.path!);
      await _uploadDocument(
        file,
        type: "police_verification_pdf",
      );
    }
  }

  Future<void> _pickAndUploadNotaryImage() async {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return SizedBox(
          height: 160,
          child: Column(
            children: [
              const SizedBox(height: 10),
              const Text(
                "Choose Image Source",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // CAMERA
                  TextButton.icon(
                    icon: const Icon(Icons.camera_alt, size: 28),
                    label: const Text("Camera"),
                    onPressed: () async {
                      Navigator.pop(context);

                      final picked = await ImagePicker().pickImage(
                        source: ImageSource.camera,
                        imageQuality: 90,
                      );

                      if (picked == null) return;

                      // Original file
                      File original = File(picked.path);
                      print("📸 BEFORE SIZE: ${(await original.length() / 1024).toStringAsFixed(2)} KB");

                      // ---- COMPRESS (first pass) ----
                      XFile? compressedX = await FlutterImageCompress.compressAndGetFile(
                        original.path,
                        "${original.path}_c1.jpg",
                        quality: 20,
                        minWidth: 800,
                        minHeight: 800,
                      );

                      if (compressedX == null) {
                        print("❌ Compression failed!");
                        return;
                      }

                      // Convert XFile → File
                      File finalFile = File(compressedX.path);

                      // ---- RECOMPRESS UNTIL UNDER 150 KB ----
                      int quality = 20;

                      while (await finalFile.length() > 150 * 1024 && quality > 5) {
                        quality -= 5;

                        XFile? retryX = await FlutterImageCompress.compressAndGetFile(
                          finalFile.path,
                          "${finalFile.path}_retry.jpg",
                          quality: quality,
                        );

                        if (retryX == null) break;

                        finalFile = File(retryX.path); // XFile → File
                      }

                      print("📸 AFTER SIZE: ${(await finalFile.length() / 1024).toStringAsFixed(2)} KB");

                      print("📤 UPLOAD ID: ${widget.agreementId}");

                      await _uploadDocument(finalFile, type: "notry_img");
                    },
                  ),

                  // GALLERY
                  TextButton.icon(
                    icon: const Icon(Icons.photo, size: 28),
                    label: const Text("Gallery"),
                    onPressed: () async {
                      Navigator.pop(context);

                      final picked = await ImagePicker()
                          .pickImage(source: ImageSource.gallery, imageQuality: 90);

                      if (picked != null) {
                        File imgFile = File(picked.path);

                        await _uploadDocument(
                          imgFile,
                          type: "notry_img",
                        );
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _uploadDocument(File file, {required String type}) async {
    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final request = http.MultipartRequest(
        "POST",
        Uri.parse("https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/agreement/update_notry_and_police_verification.php"),
      );

      request.fields["id"] = widget.agreementId;

      // Add only required field
      if (type == "notry_img") {
        request.files.add(
          await http.MultipartFile.fromPath("notry_img", file.path),
        );
      } else if (type == "police_verification_pdf") {
        request.files.add(
          await http.MultipartFile.fromPath("police_verification_pdf", file.path),
        );
      }

      debugPrint("📤 Upload Started : ${file.path}");

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();

      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pop();

      debugPrint("🌐 Response Code: ${response.statusCode}");
      debugPrint("🧾 Raw Response: $responseBody");

      if (response.statusCode == 200) {
        try {
          final data = jsonDecode(responseBody);

          if (response.statusCode == 200) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(data["message"] ?? "Upload successful"),
                backgroundColor: Colors.green,
              ),
            );
            _fetchAgreementDetail();
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text("Failed: ${data['message']}"),
                backgroundColor: Colors.redAccent,
              ),
            );
          }
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text("Response: $responseBody"),
              backgroundColor: Colors.orange,
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Upload failed: ${response.statusCode}"),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Error: $e"),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }


  String? _formatDate(dynamic shiftingDate) {
    if (shiftingDate == null) return "";
    if (shiftingDate is Map && shiftingDate["date"] != null) {
      try {
        return DateTime.parse(shiftingDate["date"])
            .toLocal()
            .toString()
            .split(" ")[0];
      } catch (e) {
        return shiftingDate["date"].toString();
      }
    }
    if (shiftingDate is String && shiftingDate.isNotEmpty) {
      return shiftingDate;
    }
    return "";
  }

  Future<void> _fetchAgreementDetail() async {
    try {
      final response = await http.get(Uri.parse(
          "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/detail_page_main_agreement.php?id=${widget.agreementId}"));

      print(widget.agreementId);

      print("API Response: ${response.body}");

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);

        // Print decoded JSON
        print("Decoded JSON: $decoded");

        if (decoded["success"] == true &&
            decoded["data"] != null &&
            decoded["data"].isNotEmpty) {
          setState(() {
            agreement = Map<String, dynamic>.from(decoded["data"][0]);
            isLoading = false;
          });
          fetchPropertyCard();
        } else {
          setState(() => isLoading = false);
        }
      } else {
        print("Error: Status code ${response.statusCode}");
        setState(() => isLoading = false);
      }
    } catch (e) {
      print("Error: $e");
      setState(() => isLoading = false);
    }
  }

  Future<void> _updatePaymentOfficeStatus({
    int? payment,
    int? officeReceived,
  })
  async {
    try {
      final body = {
        "id": widget.agreementId,
      };

      if (payment != null) {
        body["payment"] = payment.toString();
        body["payment_at"] =
            DateTime.now().toIso8601String();
      }

      if (officeReceived != null) {
        body["office_received"] = officeReceived.toString();
        body["office_received_at"] =
            DateTime.now().toIso8601String();
      }

      final response = await http.post(
        Uri.parse(
          "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/agreement/update_payment_field.php",
        ),
        body: body,
      );

      debugPrint("📄 Response body: ${response.body}");

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);

        if (decoded["status"] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Status updated successfully"),
              backgroundColor: Colors.green,
            ),
          );
          _fetchAgreementDetail(); // refresh
        } else {
          throw decoded["message"];
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Update failed: $e"),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }


  Widget _glassContainer({required Widget child, EdgeInsets? padding}) {
    final isDark = Theme
        .of(context)
        .brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isDark
            ? Colors.grey[900]!.withOpacity(0.85)
            : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark ? Colors.grey[700]! : Colors.grey.shade300,
          width: 1,
        ),
      ),
      child: child,
    );
  }

  Widget _furnitureList(dynamic furnitureData) {
    if (furnitureData == null || furnitureData.toString().trim().isEmpty) {
      return const SizedBox.shrink();
    }

    Map<String, dynamic> furnitureMap = {};
    try {
      if (furnitureData is String) {
        furnitureMap = Map<String, dynamic>.from(json.decode(furnitureData));
      } else if (furnitureData is Map<String, dynamic>) {
        furnitureMap = furnitureData;
      }
    } catch (e) {
      debugPrint("⚠️ Furniture parse error: $e");
    }

    if (furnitureMap.isEmpty) return const SizedBox.shrink();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
              'Furnished Items:',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: isDark ? Colors.white : Colors.black87)
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: furnitureMap.entries.map((e) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.green.shade100,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green.shade700, width: 1),
                ),
                child: Text(
                  "${e.key} (${e.value})",
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    color: Colors.black87,
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }


  Widget _sectionCard({required String title, required List<Widget> children}) {
    // filter out empty children
    final visibleChildren = children.where((c) => c is! SizedBox).toList();
    if (visibleChildren.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style:
              const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          _glassContainer(
            child: Column(children: visibleChildren),
            padding: const EdgeInsets.all(14),
          ),
        ],
      ),
    );
  }

  Widget _kv(String k, dynamic v) {
    final value = v.toString().trim();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              '$k:',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isPolice = agreement?["agreement_type"] == "Police Verification";
    final withPolice= agreement?['is_Police']?.toString() == "true";

    final bool paymentDone =
        agreement?["payment"]?.toString() == "1";

    final bool officeReceived =
        agreement?["office_received"]?.toString() == "1";

    if (isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (agreement == null) {
      return const Scaffold(
        body: Center(
          child: Text("No details found"),
        ),
      );
    }

    final D_or_T =
    agreement?["agreement_type"] == "Commercial Agreement"
        ? "Director"
        : "Tenant";

    final String? agreementPdf = agreement?["agreement_pdf"];
    final bool hasAgreementPdf =
        agreementPdf != null && agreementPdf.toString().isNotEmpty;


    return Scaffold(
      appBar: AppBar(
        title: Text('${agreement?["agreement_type"] ?? ""} Details'),
        leading: const SquareBackButton(),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Wrap(
                spacing: 12,
                runSpacing: 12,
                alignment: WrapAlignment.spaceEvenly,
                children: [

                  _statusCard(
                    title: "Payment Status",
                    value: paymentDone ? "Paid" : "Pending",
                    isPositive: paymentDone,
                    dateTime: agreement?["payment_at"],

                  ),

                  _statusCard(
                    title: "Office Received",
                    value: officeReceived ? "Delivered" : "Not Delivered",
                    isPositive: officeReceived,
                    dateTime: agreement?["office_received_at"],
                  ),
                ],
            ),

            SizedBox(height: 20,),
            if (withPolice)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.redAccent),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.info_outline, color: Colors.redAccent),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Note: Police verification must be created by Admin for this agreement.',
                        style: TextStyle(
                          color: Colors.redAccent,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            SizedBox(height: 20,),

            if (propertyCard != null) propertyCard!,

            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                children: [
                  if (!isPolice)
                    _buildCard(
                      title: "Agreement Details",
                      children: [
                        _kv("BHK", agreement?["Bhk"] ?? ""),
                        _kv("Floor", agreement?["floor"] ?? ""),
                        _kv("Rented Address", agreement?["rented_address"]),
                        _kv("Monthly Rent", agreement?["monthly_rent"] != null
                            ? "₹${agreement?["monthly_rent"]}"
                            : ""),
                        _kv("Security", agreement?["securitys"] != null
                            ? "₹${agreement?["securitys"]}"
                            : ""),
                        _kv("Installment Security",
                            agreement?["installment_security_amount"] != null
                                ? "₹${agreement?["installment_security_amount"]}"
                                : ""),
                        _kv("Meter", agreement?["meter"]),
                        _kv("Custom Unit", agreement?["custom_meter_unit"]),
                        _kv("Maintenance", agreement?["maintaince"]),
                        _kv("Parking", agreement?["parking"]),
                        _kv("Shifting Date",
                            _formatDate(agreement?["shifting_date"]) ?? ""),
                        _furnitureList(agreement!['furniture']),
                        _kv("Agreement Price", agreement?["agreement_price"] ?? 'Not Added'),
                        _kv("Notary Amount", agreement?["notary_price"] ?? 'Not Added'),
                      ],
                    ),


                  Column(
                      children: [
                        _buildCard(
                          title: "Owner Details",
                          children: [
                            _kv("Owner Name", agreement?["owner_name"]),
                            _kv("Relation", "${agreement?["owner_relation"] ??
                                ""} ${agreement?["relation_person_name_owner"] ??
                                ""}"),
                            _kv("Address",
                                agreement?["parmanent_addresss_owner"]),
                            _kv("Mobile", agreement?["owner_mobile_no"]),
                            _kv("Aadhar", agreement?["owner_addhar_no"]),
                            Row(
                              children: [
                                _docImage(agreement?["owner_aadhar_front"]),
                                _docImage(agreement?["owner_aadhar_back"]),
                              ],
                            )
                          ],
                        ),

                      ]
                  ),

                  Column(
                      children: [
                        _buildCard(
                          title: "$D_or_T Details",
                          children: [
                            _kv("$D_or_T Name", agreement?["tenant_name"]),
                            _kv("Relation", "${agreement?["tenant_relation"] ?? ""} ${agreement?["relation_person_name_tenant"] ?? ""}"),
                            _kv("Address",
                                agreement?["permanent_address_tenant"]),
                            _kv("Mobile", agreement?["tenant_mobile_no"]),
                            _kv("Aadhar", agreement?["tenant_addhar_no"]),

                            if (agreement!["agreement_type"] == "Commercial Agreement") ...[
                              const Divider(),
                              _kv("Company Name", agreement!["company_name"]),
                              _kv("DOC Type ", agreement!["gst_type"]),
                              _kv("DOC Number", agreement!["gst_no"]),
                              _kv("PAN Number", agreement!["pan_no"]),

                              Row(
                                children: [
                                  _docImage(agreement?["gst_photo"]),
                                  _docImage(agreement?["pan_photo"]),
                                ],
                              ),

                            ],

                            Row(
                              children: [
                                _docImage(agreement?["tenant_aadhar_front"]),
                                _docImage(agreement?["tenant_aadhar_back"]),
                              ],
                            ),
                            SizedBox(height: 10,),
                            Container(
                              margin: EdgeInsets.only(top: 10.0),
                              child: Row(
                                children: [
                                  _docImage(agreement?["tenant_image"]),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ]
                  ),

                  if (additionalTenants.isNotEmpty)
                    Column(
                      children: [
                        _buildCard(
                          title: "Additional $D_or_T",
                          children: additionalTenants.map((t) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _kv("$D_or_T Name", t.name),
                                _kv("Relation",
                                    "${t.relation} ${t.relation_name}"),
                                _kv("Address", agreement?["permanent_address_tenant"]),
                                _kv("Mobile", t.mobile),
                                _kv("Aadhar", t.aadhaar),
                                const SizedBox(height: 6),
                                Wrap(
                                  children: [
                                    _docImage(t.front),
                                    _docImage(t.back),
                                    _docImage(t.photo),
                                  ],
                                ),
                                const Divider(),
                              ],
                            );
                          }).toList(),
                        ),
                      ],
                    ),

                ],
              ),
            ),



            if (isPolice)
              _sectionCard(
                title: "Property Address",
                children: [
                  _kv("Rented Address", agreement?["rented_address"]),
                ],
              ),

            _sectionCard(title: "Field Worker", children: [
              _kv("Name", agreement!["Fieldwarkarname"]),
              _kv("Number", agreement!["Fieldwarkarnumber"]),
            ]),

            SizedBox(height: 20,),

            if (!isPolice && pdfFile != null)
              _glassContainer(
                child: ListTile(
                  leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
                  title: Text(pdfFile!.path.split('/').last),
                  subtitle: const Text("Tap to open in browser"),
                  onTap: () async {
                    final uri = Uri.file(pdfFile!.path);
                    // inside onTap
                    if (pdfFile != null) {
                      await OpenFilex.open(pdfFile!.path);
                    }
                    else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Could not open PDF")),
                      );
                    }
                  },
                ),
              ),

            SizedBox(height: 20,),

            if (!isPolice)
              GenerateAgreementButton(onGenerate: _handleGeneratePdf),

            SizedBox(height: 20,),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {
                    final pdf = agreement?["police_verification_pdf"];

                    if (pdf == null || pdf.toString().isEmpty) {
                      _pickAndUploadPoliceVerification();
                    } else {
                      _showDocumentActionSheet(
                        title: "Police Verification",
                        onView: () {
                          _launchURL(
                              'https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/agreement/$pdf'
                          );
                        },
                        onUpdate: _pickAndUploadPoliceVerification,
                      );                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: (agreement?["police_verification_pdf"] == null ||
                        agreement!["police_verification_pdf"].toString().isEmpty)
                        ? Colors.grey
                        : Colors.yellow,
                    foregroundColor: Colors.black,
                  ),
                  child: Text(
                    (agreement?["police_verification_pdf"] == null ||
                        agreement!["police_verification_pdf"].toString().isEmpty)
                        ? 'Add P. Verification'
                        : 'View P. Verification',
                  ),
                ),

                // 🔹 Notary Button
                if (!isPolice)
                  ElevatedButton(
                    onPressed: () {
                      final notary = agreement?["notry_img"];
                      if (notary == null || notary.toString().isEmpty) {
                        _pickAndUploadNotaryImage();
                      } else {
                        _showDocumentActionSheet(
                          title: "Notary Document",
                          onView: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ImagePreviewScreen(
                                  imageUrl:
                                  'https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/agreement/$notary',
                                ),
                              ),
                            );
                          },
                          onUpdate: _pickAndUploadNotaryImage,
                        );                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: (agreement?["notry_img"] == null ||
                          agreement!["notry_img"].toString().isEmpty)
                          ? Colors.grey
                          : Colors.red,
                      foregroundColor: Colors.black,
                    ),
                    child: Text(
                      (agreement?["notry_img"] == null ||
                          agreement!["notry_img"].toString().isEmpty)
                          ? 'Add Notary'
                          : 'View Notary',
                    ),
                  ),
              ],
            ),

            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [

                // 💰 PAYMENT BUTTON
                ElevatedButton(
                  onPressed: paymentDone
                      ? null
                      : () => _updatePaymentOfficeStatus(payment: 1),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                    paymentDone ? Colors.green : Colors.orange,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 12,
                    ),
                  ),
                  child: Text(
                    paymentDone ? "Payment Done" : "Mark Payment",
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),

                // 🏢 OFFICE RECEIVED BUTTON
                ElevatedButton(
                  onPressed: officeReceived
                      ? null
                      : () => _updatePaymentOfficeStatus(
                    officeReceived: 1,
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                    officeReceived ? Colors.green : Colors.blue,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 12,
                    ),
                  ),
                  child: Text(
                    officeReceived
                        ? "Office Received"
                        : "Mark Received",
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),



            const SizedBox(height: 12),

            if (!isPolice)
              Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () =>
                      _launchURL(
                      'https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/agreement/${agreement?["agreement_pdf"]}'),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue, foregroundColor: Colors.black),
                  child: const Text('View Agreement PDF'),
                ),
              ],
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildCard({required String title, required List<Widget> children}) {
    return Container(
      width: 300,
      margin: const EdgeInsets.only(right: 20),
      child: _sectionCard(title: title, children: children),
    );
  }

  Widget _docImage(String? imageUrl) {
    if (imageUrl == null || imageUrl.isEmpty) {
      return const SizedBox.shrink();
    }

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ImagePreviewScreen(
              imageUrl:
              'https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/agreement/$imageUrl',
            ),
          ),
        );
      },
      child: Container(
        width: 120,
        height: 120,
        margin: const EdgeInsets.only(right: 12),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.network(
            "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_application/agreement/$imageUrl",
            width: 160,   // force same as container
            height: 120,  // force same as container
            fit: BoxFit.cover, // ensures full fill
            errorBuilder: (context, error, stackTrace) =>
            const SizedBox.shrink(), // Hide if image fails to load
          ),
        ),
      ),
    );
  }

  _launchURL(String pdf_url) async {
    final Uri url = Uri.parse(pdf_url);
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  void _showDocumentActionSheet({
    required String title,
    required VoidCallback onView,
    required VoidCallback onUpdate,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) {
        final isDark = Theme.of(context).brightness == Brightness.dark;

        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: isDark ? Colors.grey[900] : Colors.white,
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(24),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 20,
                offset: const Offset(0, -4),
              )
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              // Top drag indicator
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 18),
                decoration: BoxDecoration(
                  color: Colors.grey.shade500,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),

              // Title
              Row(
                children: [
                  const Icon(Icons.description, size: 26),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 25),

              // Buttons Row
              Row(
                children: [

                  // View
                  Expanded(
                    child: _actionButton(
                      icon: Icons.visibility_outlined,
                      label: "View",
                      color: Colors.blue,
                      onTap: () {
                        Navigator.pop(context);
                        onView();
                      },
                    ),
                  ),

                  const SizedBox(width: 16),

                  // Update
                  Expanded(
                    child: _actionButton(
                      icon: Icons.edit_outlined,
                      label: "Update",
                      color: Colors.orange,
                      onTap: () {
                        Navigator.pop(context);
                        onUpdate();
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 15),
            ],
          ),
        );
      },
    );
  }

  Widget _propertyCard(Map<String, dynamic> data) {
    final String imageUrl =
        "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_realestate/${data['property_photo'] ?? ''}";

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 8,
      margin: const EdgeInsets.only(bottom: 20),
      shadowColor: Colors.black.withOpacity(0.15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            child: Image.network(
              imageUrl,
              height: 200,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 200,
                  width: double.infinity,
                  color: Colors.grey[200],
                  alignment: Alignment.center,
                  child: const Text("No Image",
                      style: TextStyle(color: Colors.black54)),
                );
              },
            ),
          ),

          // Details
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // BHK + Floor
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                    Text(
                      "₹${data['show_Price'] ?? "--"}",
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),

                    Text(
                      data['Bhk'] ?? "",
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      data['Floor_'] ?? "--",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[100],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Price + Meter
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                    Text(
                      "Name: ${data['field_warkar_name'] ?? "--"}",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[100],
                      ),
                    ),

                    Text(
                      "Location: ${data['locations'] ?? "--"}",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[100],
                      ),
                    ),

                  ],
                ),
                const SizedBox(height: 10),

                // // Availability
                // Text(
                //   "Available from: ${data['available_date']?.toString().split('T')[0] ?? "--"}",
                //   style: const TextStyle(
                //     fontSize: 15,
                //     fontWeight: FontWeight.w500,
                //   ),
                // ),
                // const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Meter: ${data['meter'] ?? "--"}",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[100],
                      ),
                    ),

                    Text(
                      "Parking: ${data['parking'] ?? "--"}",
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey[100],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),

                // Maintenance
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Maintenance: ${data['maintance'] ?? "--"}",
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey[100],
                      ),
                    ),

                    Text(
                      "ID: ${agreement?["property_id"] ?? "--"}",
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey[100],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

}

Widget _statusCard({
  required String title,
  required String value,
  required bool isPositive,
  String? dateTime, // 👈 NEW (ISO string from API)
})
{
  String formattedTime = "";

  if (dateTime != null && dateTime.isNotEmpty) {
    try {
      final dt = DateTime.parse(dateTime).toLocal();
      formattedTime =
      "${dt.day.toString().padLeft(2, '0')} "
          "${_monthName(dt.month)} "
          "${dt.year}, "
          "${dt.hour.toString().padLeft(2, '0')}:"
          "${dt.minute.toString().padLeft(2, '0')}";
    } catch (_) {
      formattedTime = "";
    }
  }

  return Container(
    constraints: const BoxConstraints(minWidth: 160),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: Colors.grey),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: isPositive ? Colors.green : Colors.red,
          ),
        ),

        // 🕒 TIME (only if available)
        if (formattedTime.isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(
            formattedTime,
            style: const TextStyle(
              fontSize: 11,
              color: Colors.white70,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ],
    ),
  );
}

Widget _actionButton({
  required IconData icon,
  required String label,
  required Color color,
  required VoidCallback onTap,
}) {
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(14),
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: color.withOpacity(0.1),
        border: Border.all(color: color, width: 1.5),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: color,
            ),
          )
        ],
      ),
    ),
  );
}

String _monthName(int month) {
  const months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];
  return months[month - 1];
}

class ElevatedGradientButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback onPressed;
  const ElevatedGradientButton(
      {required this.text, required this.icon, required this.onPressed, super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [Color(0xFF4CA1FF), Color(0xFF8A5CFF)]),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.18),
                blurRadius: 16,
                offset: const Offset(0, 8))
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 18),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: Colors.white),
          const SizedBox(width: 12),
          Text(text,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}
