import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_phosphor_icons/flutter_phosphor_icons.dart';
import 'package:http/http.dart' as http;
import 'package:iconsax_flutter/iconsax_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../Home_Screen_click/All_view_details.dart';
import '../../Home_Screen_click/New_Real_Estate.dart';
import '../../ui_decoration_tools/app_images.dart';


class SubAdminAllLiveProperty extends StatefulWidget {
  const SubAdminAllLiveProperty({super.key});

  @override
  State<SubAdminAllLiveProperty> createState() => _AllLiveProperty();
}

class _AllLiveProperty extends State<SubAdminAllLiveProperty> {

  List<NewRealEstateShowDateModel> _allProperties = [];
  List<NewRealEstateShowDateModel> _filteredProperties = [];
  TextEditingController _searchController = TextEditingController();

  bool _isLoading = true;
  String _number = '';
  int propertyCount = 0;
  String? selectedLabel;
  Timer? _debounce;

  @override
  void dispose() {
    _searchController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase().trim();

    final filtered = _allProperties.where((item) {
      final values = [
        item.pId?.toString(),
        item.locations,
        item.ownerName,
        item.ownerNumber,
        item.careTakerName,
        item.careTakerNumber,
        item.buyRent,
        item.apartmentAddress,
        item.fieldWorkerAddress,
        item.fieldWorkerName,
        item.fieldWorkerNumber,
        item.bhk?.toString(),
        item.floor?.toString(),
        item.typeOfProperty,
        item.flatNumber?.toString(),
        item.sId?.toString(),
        item.sourceId?.toString(),
        item.showPrice?.toString(),
      ];

      // Check if ANY field contains search text
      return values.any((v) => v != null && v.toLowerCase().contains(query));
    }).toList();

    setState(() {
      _filteredProperties = filtered;
      propertyCount = filtered.length;
    });
  }


  Future<List<NewRealEstateShowDateModel>> fetchData(String number) async {
    String baseUrl =
        "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_realestate_for_website/show_api_for_location_base_website_live_property_data.php";

    String finalUrl = baseUrl;

    // 🔥 RULE 1 → Shivani Joshi
    if (_number == "8743080855") {
      finalUrl = "$baseUrl?locations=Rajpur Khurd,ChhattarPur";
    }

    // 🔥 RULE 2 → Saurabh Yadav
    else if (_number == "9711779003") {
      finalUrl = "$baseUrl?locations=Sultanpur";
    }

    // print("🌍 API URL Used: $finalUrl");

    final url = Uri.parse(finalUrl);
    final response = await http.get(url);

    if (response.statusCode != 200) {
      throw Exception("HTTP ${response.statusCode}: ${response.body}");
    }

    final decoded = json.decode(response.body);
    final raw = decoded is Map<String, dynamic> ? decoded['data'] : decoded;

    final List<Map<String, dynamic>> listResponse;

    if (raw is List) {
      listResponse = raw.map((e) => Map<String, dynamic>.from(e)).toList();
    } else if (raw is Map) {
      listResponse = [Map<String, dynamic>.from(raw)];
    } else {
      listResponse = const [];
    }

    int _asInt(dynamic v) =>
        v is int ? v : (int.tryParse(v?.toString() ?? "0") ?? 0);

    listResponse.sort((a, b) => _asInt(b['P_id']).compareTo(_asInt(a['P_id'])));

    return listResponse
        .map((data) => NewRealEstateShowDateModel.fromJson(data))
        .toList();
  }

  @override
  void initState() {
    super.initState();

    _searchController = TextEditingController();
    _searchController.addListener(_onSearchChanged);
    _loaduserdata(); // fetch _number from SharedPreferences

    _loaduserdata().then((_) {
      _fetchInitialData(); // Call your API after loading user data
    });
  }
  String _name = '';
  String _FAadharCard = '';

  Future<void> _loaduserdata() async {
    final prefs = await SharedPreferences.getInstance();

    // Load saved data
    _number = prefs.getString('number') ?? '';
    _name = prefs.getString('name') ?? '';
    _FAadharCard = prefs.getString('FAadharCard') ?? '';

    // Fallback: if FAadharCard was stored earlier as "post"
    if (_FAadharCard.isEmpty) {
      _FAadharCard = prefs.getString('post') ?? '';
    }
    // Debug logs
    // print("🟦 Loaded Name: $_name");
    // print("🟦 Loaded Number: $_number");
    // print("🟦 Loaded FAadharCard (Role): $_FAadharCard");

    await _fetchProperties();
  }

  List<NewRealEstateShowDateModel> _applyCustomLocationFilter(List<NewRealEstateShowDateModel> list) {

    // RULE 1 → Shivani Joshi phone number
    if (_number == "8743080855") {
      return list.where((item) {
        final loc = (item.locations ?? "").trim().toLowerCase();
        return loc == "rajpur khurd" || loc == "chhattarpur";
      }).toList();
    }

    // RULE 2 → Saurabh Yadav phone number
    if (_number == "9711779003") {
      return list.where((item) {
        final loc = (item.locations ?? "").trim().toLowerCase();
        return loc == "sultanpur";
      }).toList();
    }

    // Default → Show everything
    return list;
  }

  Future<void> _fetchProperties() async {
    setState(() => _isLoading = true);

    try {
      final data = await fetchData(_number);

      // 🔥 APPLY PHONE-BASED LOCATION FILTER
      final filteredList = _applyCustomLocationFilter(data);

      setState(() {
        _allProperties = filteredList;
        _filteredProperties = filteredList;
        _isLoading = false;
      });
    } catch (e) {
      print("❌ Error: $e");
      setState(() => _isLoading = false);
    }
  }



  Future<void> _fetchInitialData() async {
    setState(() => _isLoading = true);
    try {
      final data = await fetchData(""); // Call your API
      setState(() {
        // _originalData = data;
        // _filteredData = data;
        _isLoading = false;
      });
    } catch (e) {
      print("❌ Error fetching data: $e");
      setState(() => _isLoading = false);
    }
  }




  void _setSearchText(String label, String text) {
    setState(() {
      selectedLabel = label;
      _searchController.text = text;
      _searchController.selection = TextSelection.fromPosition(
        TextPosition(offset: _searchController.text.length),

      );
      // propertyCount = _getMockPropertyCount(text); // Mock or real count

    });

    print("Search for: $text");
  }
  bool get _isSearchActive {
    return _searchController.text.trim().isNotEmpty || selectedLabel!="";
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      _isLoading
          ? Center(child: Image.asset(AppImages.loader,height: 50,))
          : Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              keyboardType: TextInputType.visiblePassword,
              style: TextStyle(
                color: Theme.of(context).textTheme.bodyLarge?.color,
                fontSize: 16,
              ),
              decoration: InputDecoration(
                hintText: 'Search properties',
                hintStyle: TextStyle(
                  color: Theme.of(context).hintColor,
                  fontSize: 16,
                ),
                prefixIcon: Icon(
                  Icons.search_rounded,
                  color: Theme.of(context).iconTheme.color?.withOpacity(0.8),
                ),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                  icon: Icon(
                    Icons.clear_rounded,
                    color: Theme.of(context).iconTheme.color?.withOpacity(0.6),
                  ),
                  onPressed: () => _searchController.clear(),
                )
                    : null,
                filled: true,
                fillColor: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.4),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: Theme.of(context).colorScheme.outline.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: Theme.of(context).colorScheme.primary,
                    width: 1.5,
                  ),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
          if (propertyCount > 0 && _isSearchActive)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [

                  Icon(Icons.check_circle_outline, color: Colors.green, size: 20),
                  const SizedBox(width: 6),
                  Text(
                    "Total : $propertyCount",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),

                ],
              ),
            ),
          _filteredProperties.isEmpty
              ? Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.search_off, size: 60, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text(
                    "No properties found",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Try a different search term",
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
            ),
          )
              : Expanded(
            child: RefreshIndicator(
              onRefresh: _fetchProperties,
              child: ListView.builder(
                itemCount: _filteredProperties.length,
                itemBuilder: (context, index) {
                  final property = _filteredProperties[index];
                  return StreamBuilder<http.Response>(
                    stream: Stream.periodic(const Duration(seconds: 5))
                        .asyncMap((_) => http.get(Uri.parse(
                      "https://verifyrealestateandservices.in/WebService4.asmx/Count_api_flat_under_future_property_by_cctv?CCTV=${_filteredProperties[index].pId??0}",
                    ))),
                    builder: (context, snapshot) {
                      bool isRedDot = false;

                      if (snapshot.hasData) {
                        try {
                          final body = jsonDecode(snapshot.data!.body);
                          isRedDot = body is List && body.isNotEmpty && body[0]['logg'] == 0;
                        } catch (_) {}
                      }

                      final Map<String, dynamic> fields = {
                        "Images": property.propertyPhoto,
                        "Owner Name": property.ownerName,
                        "Owner Number": property.ownerNumber,
                        "Caretaker Name": property.careTakerName,
                        "Caretaker Number": property.careTakerNumber,
                        "Place": property.locations,
                        "Buy/Rent": property.buyRent,
                        "Property Name/Address": property.apartmentAddress,
                        "Property Address (Fieldworker)":
                        property.fieldWorkerAddress,
                        // "Owner Vehicle Number": property.ownerVehicleNumber,
                        // "Your Address": property.fieldWorkerCurrentLocation,
                        "Field Worker Name": property.fieldWorkerName,
                        "Field Worker Number": property.fieldWorkerNumber,
                        "Current Date": property.currentDates,
                        "Longitude": property.longitude,
                        "Latitude": property.latitude,
                        "Road Size": property.roadSize,
                        "Metro Distance": property.metroDistance,
                        "Metro Name": property.highwayDistance,
                        "Main Market Distance": property.mainMarketDistance,
                        "Age of Property": property.ageOfProperty,
                        "Lift": property.lift,
                        "Parking": property.parking,
                        "Total Floor": property.totalFloor,
                        "Residence/Commercial": property.typeOfProperty,
                        "Facility": property.facility,
                        "Video": property.video,
                      };

                      final missingFields = fields.entries
                          .where((entry) {
                        final value = entry.value;
                        if (value == null) return true;
                        if (value is String && value.trim().isEmpty) return true;
                        return false;
                      })
                          .map((entry) => entry.key)
                          .toList();

                      final hasMissingFields = missingFields.isNotEmpty;
                      return Column(
                          children: [
                            GestureDetector(
                              onTap: () async {
                                SharedPreferences prefs = await SharedPreferences.getInstance();
                                prefs.setInt('id_Building', _filteredProperties[index].pId??0);
                                prefs.setString('id_Longitude', _filteredProperties[index].longitude.toString());
                                prefs.setString('id_Latitude', _filteredProperties[index].latitude.toString());
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => AllViewDetails(id: _filteredProperties[index].pId??0),
                                  ),
                                );
                                print(_filteredProperties[index].pId??0);
                              },
                              child: Container(
                                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),

                                child: Card(
                                  elevation: 4, // ✅ elevation added
                                  shadowColor:  Theme.of(context).brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  color: Theme.of(context).brightness==Brightness.dark?Colors.white:Colors.white,
                                  child:
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Stack(
                                        children: [
                                          Container(
                                            height: 450,
                                            width: double.infinity,
                                            decoration: BoxDecoration(
                                              color: Theme.of(context).highlightColor,
                                              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                                            ),
                                            child: Image.network(
                                              "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_realestate/${_filteredProperties[index].propertyPhoto}",
                                              fit: BoxFit.cover,
                                              errorBuilder: (context, error, stackTrace) => Center(
                                                child: Icon(Icons.home, size: 50, color: Theme.of(context).hintColor),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            top: 12,
                                            right: 12,
                                            child: Wrap(
                                              spacing: 8,
                                              children: [
                                                _buildFeatureItem(
                                                  context: context,
                                                  text: "Live Property ID : ${_filteredProperties[index].pId}",
                                                  borderColor: Colors.grey.shade700,
                                                  backgroundColor: Colors.white,
                                                  textColor: Colors.blue,
                                                  shadowColor: Colors.white60,
                                                ),  _buildFeatureItem(
                                                  context: context,
                                                  //
                                                  text: "For: ${_filteredProperties[index].buyRent}" ?? "Property",
                                                  borderColor: Colors.green.shade400,
                                                  backgroundColor: Colors.green.shade100,
                                                  textColor: Colors.green.shade700,
                                                  shadowColor: Colors.green.shade100,
                                                ),

                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            bottom: 0,
                                            right: 0,
                                            child:
                                            _buildFeatureItem(
                                              context: context,
                                              text: "Added by : ${_filteredProperties[index].fieldWorkerName}",
                                              borderColor: Colors.red.shade400,
                                              backgroundColor: Colors.red.shade200,
                                              textColor: Colors.white,
                                              shadowColor: Colors.white60,
                                            ),
                                          ),
                                        ],
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(16),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Text(
                                                  "₹${_filteredProperties[index].showPrice??"-"
                                                      ".0"}"
                                                  ,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 20,
                                                    fontFamily: "PoppinsBold",
                                                    color: Colors.black,
                                                  ),
                                                ),
                                                Text(
                                                  _filteredProperties[index].locations ?? "",
                                                  style: TextStyle(
                                                    fontFamily: "PoppinsBold",
                                                    color: Colors.black,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 8),
                                            Wrap(
                                              spacing: 4, // horizontal spacing between items
                                              runSpacing: 8, // vertical spacing between lines
                                              alignment: WrapAlignment.start,
                                              children: [
                                                _buildFeatureItem(
                                                  context: context,
                                                  icon: Icons.king_bed,
                                                  text: "${_filteredProperties[index].bhk}",
                                                  borderColor: Colors.purple.shade200,
                                                  backgroundColor: Colors.purple.shade50,
                                                  textColor: Colors.purple.shade700,
                                                  shadowColor: Colors.purple.shade100,
                                                ),
                                                _buildFeatureItem(
                                                  context: context,
                                                  icon: Icons.apartment,
                                                  text: "${_filteredProperties[index].floor}",
                                                  borderColor: Colors.teal.shade200,
                                                  backgroundColor: Colors.teal.shade50,
                                                  textColor: Colors.teal.shade700,
                                                  shadowColor: Colors.teal.shade100,
                                                ),
                                                _buildFeatureItem(
                                                  context: context,
                                                  icon: Icons.home_work,
                                                  text: _filteredProperties[index].typeOfProperty ?? "",
                                                  borderColor: Colors.orange.shade200,
                                                  backgroundColor: Colors.orange.shade50,
                                                  textColor: Colors.orange.shade700,
                                                  shadowColor: Colors.orange.shade100,
                                                ),

                                                _buildFeatureItem(
                                                  context: context,
                                                  icon: Icons.receipt_rounded,
                                                  text: "Flat No. ${_filteredProperties[index].flatNumber}",
                                                  borderColor: Colors.red.shade200,
                                                  backgroundColor: Colors.red.shade50,
                                                  textColor: Colors.red.shade700,
                                                  shadowColor: Colors.red.shade100,
                                                ),

                                                _filteredProperties[index].sId != null && _filteredProperties[index].sId != 0
                                                    ? _buildFeatureItem(
                                                  context: context,
                                                  text: "Building ID : ${_filteredProperties[index].sId.toString()}",
                                                  borderColor: Colors.deepOrange.shade400,
                                                  backgroundColor: Colors.deepOrange.shade100,
                                                  textColor: Colors.deepOrange.shade700,
                                                  shadowColor: Colors.deepOrange.shade100,
                                                )
                                                    : SizedBox.shrink(), // Empty widget if condition is not met


                                                _buildFeatureItem(
                                                  context: context,
                                                  text: "Building Flat ID : ${_filteredProperties[index].sourceId.toString()}",
                                                  borderColor: Colors.blue.shade400,
                                                  backgroundColor: Colors.blue.shade100,
                                                  textColor: Colors.blue.shade700,
                                                  shadowColor: Colors.blue.shade100,
                                                )

                                              ],
                                            ),
                                            if (hasMissingFields) ...[
                                              SizedBox(height: 20),
                                              Container(
                                                width: double.infinity,
                                                padding: const EdgeInsets.all(10),
                                                decoration: BoxDecoration(
                                                  color: Colors.red[50],
                                                  borderRadius: BorderRadius.circular(10),
                                                  border: Border.all(color: Colors.redAccent, width: 1),
                                                ),
                                                child: Text(
                                                  "⚠ Missing fields: ${missingFields.join(", ")}",
                                                  style: const TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w600,
                                                    color: Colors.redAccent,
                                                  ),
                                                ),
                                              ),
                                            ]
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ]
                      );
                    },
                  );

                },
              ),
            ),
          ),
        ],
      ),

      // bottomNavigationBar: Padding(
      //   padding: const EdgeInsets.only(bottom: 30,left: 8,right: 8),
      //   child: Container(
      //     decoration: BoxDecoration(
      //       borderRadius: BorderRadius.circular(6),
      //       boxShadow: [
      //         BoxShadow(
      //           color: Colors.black.withOpacity(0.2),
      //           blurRadius: 10,
      //           offset: const Offset(0, 5),
      //         ),
      //       ],
      //       gradient: LinearGradient(
      //         colors: [Colors.blueAccent, Colors.lightBlueAccent],
      //         begin: Alignment.centerLeft,
      //         end: Alignment.centerRight,
      //       ),
      //     ),
      //     child: ElevatedButton.icon(
      //       onPressed: () {
      //         Navigator.of(context).push(MaterialPageRoute(builder: (context) => RegisterProperty()));
      //         // Navigator.of(context).push(MaterialPageRoute(builder: (context) => AddPropertiesFirstPage()));
      //       },
      //       icon: const Icon(Icons.add, color: Colors.white),
      //       label: const Text(
      //         'Add Property',
      //         style: TextStyle(
      //           fontSize: 17,
      //           fontFamily: "PoppinsBold",
      //           fontWeight: FontWeight.w600,
      //           letterSpacing: 0.5,
      //           color: Colors.white,
      //         ),
      //       ),
      //       style: ElevatedButton.styleFrom(
      //         elevation: 0, // Shadow handled by container
      //         backgroundColor: Colors.transparent,
      //         shadowColor: Colors.transparent,
      //         shape: RoundedRectangleBorder(
      //           borderRadius: BorderRadius.circular(16),
      //         ),
      //         padding: const EdgeInsets.symmetric(vertical: 16),
      //       ),
      //     ),
      //   ),
      // ),
    );
  }


  Color _getPropertyTypeColor(String? type) {
    switch (type?.toLowerCase()) {
      case 'rent':
        return Colors.green;
      case 'buy':
        return Colors.blueAccent;
      case 'lease':
        return Colors.purple;
      default:
        return Colors.blue;
    }
  }

  Widget _buildFeatureItem({
    required BuildContext context,
    required String text,
    required Color borderColor,
    IconData? icon, // 👈 optional now
    Color? backgroundColor,
    Color? textColor,
    Color? shadowColor,
  }) {
    final width = MediaQuery.of(context).size.width;

    // Scale text, padding, and icon size relative to screen width
    double fontSize = width < 350 ? 10 : (width < 500 ? 12 : 14);
    double horizontalPadding = width < 350 ? 8 : (width < 500 ? 12 : 14);
    double verticalPadding = width < 350 ? 6 : (width < 500 ? 8 : 12);
    double iconSize = width < 350 ? 14 : (width < 500 ? 16 : 18);

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: horizontalPadding,
        vertical: verticalPadding,
      ),
      margin: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: backgroundColor ?? Colors.transparent,
        border: Border.all(color: borderColor, width: 2),
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: (shadowColor ?? borderColor).withOpacity(0.10),
            blurRadius: 6,
            spreadRadius: 2,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[ // 👈 only shows if passed
            Icon(
              icon,
              size: iconSize,
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : (textColor ?? Colors.black),
            ),
            const SizedBox(width: 4),
          ],
          Text(
            text,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              fontFamily: "Poppins",
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : (textColor ?? Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
