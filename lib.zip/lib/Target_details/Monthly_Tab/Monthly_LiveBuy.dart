import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:verify_feild_worker/Custom_Widget/constant.dart';

import 'Monthly_under_detail/Monthlu_Livebuy_details.dart';

/// =======================
/// MODEL
/// =======================
class LiveMonthlyBuyModel {
  final int id;

  final String image;
  final String locations;
  final String flatNumber;
  final String buyRent;
  final String residenceCommercial;
  final String apartmentName;
  final String apartmentAddress;
  final String typeOfProperty;
  final String bhk;

  final String showPrice;
  final String lastPrice;
  final String askingPrice;

  final String floor;
  final String totalFloor;
  final String balcony;
  final String squareFit;
  final String maintaince;
  final String parking;
  final String ageOfProperty;

  final String fieldworkerAddress;
  final String roadSize;
  final String metroDistance;
  final String highwayDistance;
  final String mainMarketDistance;
  final String meter;

  final String ownerName;
  final String ownerNumber;

  final String currentDates;
  final String availableDate;

  final String kitchen;
  final String bathroom;
  final String lift;
  final String facility;
  final String furnishedUnfurnished;

  final String fieldWorkerName;
  final String liveUnlive;
  final String fieldWorkerNumber;

  final String registryAndGpa;
  final String loan;

  final String longitude;
  final String latitude;
  final String videoLink;

  final String caretakerName;
  final String caretakerNumber;

  final String sourceId;
  final String dateForTarget;
  final String localityList;

  LiveMonthlyBuyModel({
    required this.id,
    required this.image,
    required this.locations,
    required this.flatNumber,
    required this.buyRent,
    required this.residenceCommercial,
    required this.apartmentName,
    required this.apartmentAddress,
    required this.typeOfProperty,
    required this.bhk,
    required this.showPrice,
    required this.lastPrice,
    required this.askingPrice,
    required this.floor,
    required this.totalFloor,
    required this.balcony,
    required this.squareFit,
    required this.maintaince,
    required this.parking,
    required this.ageOfProperty,
    required this.fieldworkerAddress,
    required this.roadSize,
    required this.metroDistance,
    required this.highwayDistance,
    required this.mainMarketDistance,
    required this.meter,
    required this.ownerName,
    required this.ownerNumber,
    required this.currentDates,
    required this.availableDate,
    required this.kitchen,
    required this.bathroom,
    required this.lift,
    required this.facility,
    required this.furnishedUnfurnished,
    required this.fieldWorkerName,
    required this.liveUnlive,
    required this.fieldWorkerNumber,
    required this.registryAndGpa,
    required this.loan,
    required this.longitude,
    required this.latitude,
    required this.videoLink,
    required this.caretakerName,
    required this.caretakerNumber,
    required this.sourceId,
    required this.dateForTarget,
    required this.localityList,
  });

  factory LiveMonthlyBuyModel.fromJson(Map<String, dynamic> json) {
    return LiveMonthlyBuyModel(
      id: int.tryParse(json['P_id']?.toString() ?? '0') ?? 0,

      image: json['property_photo']?.toString() ?? '',
      locations: json['locations']?.toString() ?? '',
      flatNumber: json['Flat_number']?.toString() ?? '',
      buyRent: json['Buy_Rent']?.toString() ?? '',
      residenceCommercial: json['Residence_Commercial']?.toString() ?? '',
      apartmentName: json['Apartment_name']?.toString() ?? '',
      apartmentAddress: json['Apartment_Address']?.toString() ?? '',
      typeOfProperty: json['Typeofproperty']?.toString() ?? '',
      bhk: json['Bhk']?.toString() ?? '',

      showPrice: json['show_Price']?.toString() ?? '',
      lastPrice: json['Last_Price']?.toString() ?? '',
      askingPrice: json['asking_price']?.toString() ?? '',

      floor: json['Floor_']?.toString() ?? '',
      totalFloor: json['Total_floor']?.toString() ?? '',
      balcony: json['Balcony']?.toString() ?? '',
      squareFit: json['squarefit']?.toString() ?? '',
      maintaince: json['maintance']?.toString() ?? '',
      parking: json['parking']?.toString() ?? '',
      ageOfProperty: json['age_of_property']?.toString() ?? '',

      fieldworkerAddress: json['fieldworkar_address']?.toString() ?? '',
      roadSize: json['Road_Size']?.toString() ?? '',
      metroDistance: json['metro_distance']?.toString() ?? '',
      highwayDistance: json['highway_distance']?.toString() ?? '',
      mainMarketDistance: json['main_market_distance']?.toString() ?? '',
      meter: json['meter']?.toString() ?? '',

      ownerName: json['owner_name']?.toString() ?? '',
      ownerNumber: json['owner_number']?.toString() ?? '',

      currentDates: json['current_dates']?.toString() ?? '',
      availableDate: json['available_date']?.toString() ?? '',

      kitchen: json['kitchen']?.toString() ?? '',
      bathroom: json['bathroom']?.toString() ?? '',
      lift: json['lift']?.toString() ?? '',
      facility: json['Facility']?.toString() ?? '',
      furnishedUnfurnished: json['furnished_unfurnished']?.toString() ?? '',

      fieldWorkerName: json['field_warkar_name']?.toString() ?? '',
      liveUnlive: json['live_unlive']?.toString() ?? '',
      fieldWorkerNumber: json['field_workar_number']?.toString() ?? '',

      registryAndGpa: json['registry_and_gpa']?.toString() ?? '',
      loan: json['loan']?.toString() ?? '',

      longitude: json['Longitude']?.toString() ?? '',
      latitude: json['Latitude']?.toString() ?? '',
      videoLink: json['video_link']?.toString() ?? '',

      caretakerName: json['care_taker_name']?.toString() ?? '',
      caretakerNumber: json['care_taker_number']?.toString() ?? '',

      sourceId: json['source_id']?.toString() ?? '',
      dateForTarget: json['date_for_target']?.toString() ?? '',
      localityList: json['locality_list']?.toString() ?? '',
    );
  }
}

/// =======================
/// API FETCH (BUY ONLY)
/// =======================
Future<List<LiveMonthlyBuyModel>> fetchLiveMonthlyBuy() async {
  final prefs = await SharedPreferences.getInstance();
  final FNumber = prefs.getString('number') ?? "";
  print(FNumber);
  final url = Uri.parse(
    "https://verifyrealestateandservices.in/Second%20PHP%20FILE/Target_New_2026/live_monthly_show.php?field_workar_number=$FNumber",
  );

  final res = await http.get(url);

  if (res.statusCode != 200) {
    throw Exception("Live Monthly API Error");
  }

  final decoded = json.decode(res.body);
  print(res.body);

  final List list = decoded['data'] ?? [];

  /// ✅ ONLY BUY
  final buyOnly = list.where((e) => e['Buy_Rent'] == 'Buy').toList();

  return buyOnly.map((e) => LiveMonthlyBuyModel.fromJson(e)).toList();
}

/// =======================
/// UI SCREEN
/// =======================
class MonthlyLiveBuyScreen extends StatefulWidget {
  const MonthlyLiveBuyScreen({super.key});

  @override
  State<MonthlyLiveBuyScreen> createState() => _MonthlyLiveBuyScreenState();
}

class _MonthlyLiveBuyScreenState extends State<MonthlyLiveBuyScreen> {
  late Future<List<LiveMonthlyBuyModel>> futureData;

  @override
  void initState() {
    super.initState();
    futureData = fetchLiveMonthlyBuy();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Image.asset(AppImages.transparent, height: 40),
        centerTitle: true,
      ),
      body: FutureBuilder<List<LiveMonthlyBuyModel>>(
        future: futureData,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snap.hasError) {
            return Center(child: Text("Error: ${snap.error}"));
          }

          final list = snap.data ?? [];

          if (list.isEmpty) {
            return const Center(child: Text("No Live Buy Found"));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final b = list[i];

              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => LiveMonthlyBuyDetailScreen(p: b),
                    ),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 18),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    color: theme.cardColor,
                    boxShadow: theme.brightness == Brightness.dark
                        ? []
                        : [
                      BoxShadow(
                        blurRadius: 12,
                        color: Colors.black.withOpacity(.08),
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      /// 🔥 IMAGE + BADGE
                      Stack(
                        children: [

                          ClipRRect(
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(22),
                            ),
                            child: Image.network(
                              "https://verifyrealestateandservices.in/Second%20PHP%20FILE/main_realestate/${b.image}",
                              height: 210,
                              width: double.infinity,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                height: 210,
                                color: Colors.grey,
                              ),
                            ),
                          ),

                          /// BUY BADGE 😎
                          Positioned(
                            top: 14,
                            left: 14,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(30),
                              ),
                              child: const Text(
                                "BUY",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 11,
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                          ),

                          /// PRICE BADGE 🔥
                          Positioned(
                            bottom: 14,
                            right: 14,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(.75),
                                borderRadius: BorderRadius.circular(30),
                              ),
                              child: Text(
                                "₹ "+b.showPrice,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      /// 🔥 CONTENT
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            /// LOCATION
                            Text(
                              "${b.locations} • ${b.localityList}",
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: Colors.grey,
                              ),
                            ),

                            const SizedBox(height: 14),

                            /// ICON ROW 😎
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                _ModernInfo(Icons.home_outlined, b.bhk),
                                _ModernInfo(Icons.layers_outlined, b.floor),
                                _ModernInfo(Icons.local_parking_outlined, b.parking),
                              ],
                            ),

                            const SizedBox(height: 14),

                            /// OWNER
                            Text(
                              "Owner: ${b.ownerName} (${b.ownerNumber})",
                              style: theme.textTheme.bodySmall,
                            ),

                            const SizedBox(height: 4),

                            /// FIELD WORKER
                            Text(
                              "Field Worker: ${b.fieldWorkerName}",
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );

            },
          );
        },
      ),
    );
  }
}
class _ModernInfo extends StatelessWidget {
  final IconData icon;
  final String text;

  const _ModernInfo(this.icon, this.text);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 18),
        const SizedBox(width: 6),
        Text(
          text.isEmpty ? "-" : text,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}

String formatMoney(String value) {
  if (value.isEmpty) return "₹0";

  final number = double.tryParse(value) ?? 0;

  return NumberFormat.currency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 0,
  ).format(number);
}

