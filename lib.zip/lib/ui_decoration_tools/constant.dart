class AppImages{
  static const vehicle = "assets/images/carshundred.png";
  static const documents = "assets/images/Documenthundred.png";
  static const hotels = "assets/images/hotelhundred.png";
  static const insurance = "assets/images/insurancehundred.png";
  static const itAndDesigner = "assets/images/itdesignhundred.png";
  static const jobs = "assets/images/jobshundred.png";
  static const consultantAndLowers = "assets/images/lawershundred.png";
  static const notification = "assets/images/notificatiohundred.png";
  static const realEstate = "assets/images/realestatehundred.png";
  static const services = "assets/images/serviceshundred.png";
  static const trucksAndJcb = "assets/images/truckshundred.png";
  static const eventsAndWeeding = "assets/images/weedinghundred.png";
  static const verify = "assets/images/nim_lopgo.png";
  static const verify_again = "assets/images/nim_lopgo.png";
  static const logo = "assets/images/VerifyLogo.png";
  static const menu="assets/images/menu.png";
  static const scanner="assets/images/scanner.png";
  static const imageNotFound="assets/images/image_not_found.png";
  static const loading="assets/images/loading_shimmer.gif";
  static const comingSoon="assets/images/comingsoon.png";
  static const tenant="assets/images/tenant.png";
  static const maintenant="assets/images/maintenant.png";
  static const property="assets/images/property.png";
  static const propertysale="assets/images/propertysale.png";
  static const tenantprofile="assets/images/tenant.png";
  static const email="assets/images/email.png";
  static const work="assets/images/briefcase.png";
  static const servant="assets/images/servant.png";
  static const persnol_Logo="assets/images/persnollogo.jpeg";
  static const Tick="assets/images/green_tick.png";
  static const Statistics="assets/images/statistics.png";
  static const realestatefeild="assets/images/realestatefeild.png";
  static const houseRealEstate="assets/images/houseRealEstate.png";
  static const rentaggrement="assets/images/rentaggrement.png";
  static const police="assets/images/police.png";
  static const car_insu="assets/images/Cars_iiiii.png";
  static const realestate_pro="assets/images/realestate_pro.png";
  static const verify_Property="assets/images/verified_property.png";
  static const rent_pro="assets/images/rrrrrreeeennnn.png";
  static const whatsaap="assets/images/whatsapp.png";
  static const call="assets/images/call.png";
  static const agreement='assets/images/deals.png';
  static const agreement_details='assets/images/search.png';
  static const futureProperty='assets/images/future_Property.png';
  static const loader = 'assets/images/loading.gif';
  static const loadingHand = 'assets/images/loadingHand.json';



  static const static1 = "assets/images/carregister.jpg";
  static const static2 = "assets/images/documentthree.jpg";
  static const static3 = "assets/images/documenttwo.jpg";
  static const static4 = "assets/images/doumentone.jpg";
  static const static5 = "assets/images/evcars.jpg";
  static const static6 = "assets/images/lease.jpg";
  static const static7 = "assets/images/salecars.jpg";
  static const static8 = "assets/images/tenent.jpg";
}

List<String> staticImages = [
  AppImages.static1,
  AppImages.static2,
  AppImages.static3,
  AppImages.static4,
  AppImages.static5,
  AppImages.static6,
  AppImages.static7,
  AppImages.static8,
];